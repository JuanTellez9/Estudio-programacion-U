defmodule DatosLogicos do
  def main do
    "Ingrese la antiguedad del cliente: "
    |> Util2.ingresar(:entero)
    |> obtener_porcentaje_descuento()
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  # def obtener_porcentaje_descuento(antiguedad) do
  #   if antiguedad < 1 do
  #     0.0
  #   else
  #     if antiguedad <= 2 do
  #       10.0
  #     else
  #       if antiguedad <= 6 do
  #         14.0
  #       else
  #         17.0
  #       end
  #     end
  #   end
  # end

  # def obtener_porcentaje_descuento(antiguedad)
  #     when antiguedad < 1, do: 0.0

  # def obtener_porcentaje_descuento(antiguedad)
  #     when antiguedad <= 2, do: 10.0

  # def obtener_porcentaje_descuento(antiguedad)
  #     when antiguedad <= 6, do: 14.0

  # def obtener_porcentaje_descuento(_), do: 17.0

  def obtener_porcentaje_descuento(antiguedad) do
    cond do
      antiguedad < 1 -> 0.0
      antiguedad <= 2 -> 10.0
      antiguedad <= 6 -> 14.0
      true -> 17.0
    end
  end

  def generar_mensaje(porcentaje) do
    "El porcentaje es de #{porcentaje}%"
  end
end

DatosLogicos.main()
