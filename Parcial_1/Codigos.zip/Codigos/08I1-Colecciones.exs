defmodule Colecciones do
  def main do
    Util2.ingresar(&Reserva.ingresar/0, :coleccion)
    |> Util2.ordenar(:asc, &{&1.nombre, &1.necesidad_especial})
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
