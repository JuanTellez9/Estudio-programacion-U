defmodule Calculadora do
  def main do
    numero1 = Util2.ingresar("Ingrese el primer número: ", :entero)
    numero2 = Util2.ingresar("Ingrese el segundo número: ", :entero)

    operacion =
      Util2.ingresar(
        "Escriba 1 para suma, 2 para resta, 3 para multiplicación, 4 para división: ",
        :entero
      )

    validar_operacion(numero1, numero2, operacion)
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  defp validar_operacion(numero1, numero2, operacion) when operacion in 1..4 do
    operar(numero1, numero2, operacion)
  end

  defp validar_operacion(_, _, _), do: {:error, "Operación no válida."}

  defp operar(numero1, numero2, 1), do: {:ok, numero1 + numero2}
  defp operar(numero1, numero2, 2), do: {:ok, numero1 - numero2}
  defp operar(numero1, numero2, 3), do: {:ok, numero1 * numero2}
  defp operar(_numero1, 0, 4), do: {:error, "División por cero no permitida."}
  defp operar(numero1, numero2, 4), do: {:ok, numero1 / numero2}

  defp generar_mensaje({:ok, resultado}), do: "El resultado es: #{resultado}"
  defp generar_mensaje({:error, mensaje}), do: "Error: #{mensaje}"
end

Calculadora.main()
