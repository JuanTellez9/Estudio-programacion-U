defmodule Colecciones do
  def main do
    ["Diana", "Julian", "Juan", "Ana"]
    |> Util2.ordenar(:desc, &String.length/1)
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
