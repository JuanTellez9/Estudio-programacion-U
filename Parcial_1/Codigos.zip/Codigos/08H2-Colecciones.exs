defmodule Coleccion do
  def main do
    reservas = [
      Reserva.crear("Ana", 18, true),
      Reserva.crear("Juan", 21),
      Reserva.crear("Cesar", 48, true),
      Reserva.crear("Anibal", 65)
    ]

    orden_nombre = Util2.ordenar(reservas, :asc, & &1.nombre)
    orden_edad = Util2.ordenar(reservas, :asc, & &1.edad)

    Util2.mostrar("\nORDEN POR NOMBRE\n", :mensaje)

    orden_nombre
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)

    Util2.mostrar("\nORDEN POR EDAD\n", :mensaje)

    orden_edad
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Coleccion.main()
