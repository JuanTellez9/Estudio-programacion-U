defmodule Ventas do
  def main do
    ventas = ventas_del_dia()

    categorias = obtener_categorias_unicas(ventas)
    productos_por_categoria = agrupar_productos_por_categoria(ventas)
    ventas_por_categoria = contar_ventas_por_categoria(ventas)
    unidades_por_categoria = sumar_unidades_por_categoria(ventas)

    venta_alta = hay_venta_alta?(ventas)
    son_validas = ventas_validas?(ventas)

    primera_bebida = buscar_primera_venta_categoria(ventas, "Bebidas")
    primer_lacteo = buscar_primera_venta_categoria(ventas, "Lácteos")

    IO.inspect(categorias, label: "Categorías")
    IO.inspect(productos_por_categoria, label: "Productos por categoría")
    IO.inspect(ventas_por_categoria, label: "Ventas por categoría")
    IO.inspect(unidades_por_categoria, label: "Unidades por categoría")

    Util2.mostrar("¿Alguna venta de más de 4 unidades? #{venta_alta}", :mensaje)
    Util2.mostrar("¿Todas las ventas son válidas? #{son_validas}", :mensaje)

    IO.inspect(primera_bebida, label: "Primera venta de Bebidas")
    IO.inspect(primer_lacteo, label: "Primera venta de Lácteos")
  end

  defp ventas_del_dia do
    [
      %{producto: "Café", categoria: "Bebidas", cantidad: 3},
      %{producto: "Té", categoria: "Bebidas", cantidad: 1},
      %{producto: "Jugo", categoria: "Bebidas", cantidad: 6},
      %{producto: "Pan", categoria: "Panadería", cantidad: 5},
      %{producto: "Croissant", categoria: "Panadería", cantidad: 2},
      %{producto: "Torta", categoria: "Panadería", cantidad: 1},
      %{producto: "Galleta", categoria: "Panadería", cantidad: 3}
    ]
  end

  defp obtener_categorias_unicas(ventas) do
    ventas
    |> Enum.map(fn venta -> venta.categoria end)
    |> Enum.uniq()
  end

  defp agrupar_productos_por_categoria(ventas) do
    Enum.group_by(ventas, fn venta -> venta.categoria end, fn venta -> venta.producto end)
  end

  defp contar_ventas_por_categoria(ventas) do
    Enum.frequencies_by(ventas, fn venta -> venta.categoria end)
  end

  defp sumar_unidades_por_categoria(ventas) do
    Enum.reduce(ventas, %{}, fn venta, acumulador ->
      Map.update(acumulador, venta.categoria, venta.cantidad, fn total ->
        total + venta.cantidad
      end)
    end)
  end

  # ¿Se vendió algún producto con más de 4 unidades? (Enum.any?)
  defp hay_venta_alta?(ventas) do
    Enum.any?(ventas, fn venta -> venta.cantidad > 4 end)
  end

  # ¿Todas las ventas tienen cantidad positiva? (Enum.all?)
  defp ventas_validas?(ventas) do
    Enum.all?(ventas, fn venta -> venta.cantidad > 0 end)
  end

  # Primera venta de una categoría dada (Enum.find devuelve nil si ninguna coincide)
  defp buscar_primera_venta_categoria(ventas, categoria) do
    Enum.find(ventas, fn venta -> venta.categoria == categoria end)
  end
end

Ventas.main()
