defmodule Estudiantes do
  def main do
    # Ahora tenemos una lista de mapas
    lista = [
      %{nombre: "pepe", nota: 3},
      %{nombre: "maria", nota: 4},
      %{nombre: "juan", nota: 4.6},
      %{nombre: "luisa", nota: 1.6},
      %{nombre: "carlos", nota: 2.3},
      %{nombre: "ana", nota: 4.5},
      %{nombre: "marcos", nota: 1}
    ]

    promedio = calcular_promedio(lista)
    Util2.mostrar("El promedio es #{promedio}", :mensaje)

    {menores, mayores} = contar_segun_promedio(lista, promedio)
    Util2.mostrar("Hay #{menores} por debajo del promedio y #{mayores} por encima", :mensaje)

    {menor, mayor} = obtener_estudiantes_min_max(lista)

    Util2.mostrar(
      "La nota más baja es de #{menor.nombre} (#{menor.nota}) y la más alta es de #{mayor.nombre} (#{mayor.nota})",
      :mensaje
    )

    {aprobados, reprobados} = contar_aprobados_reprobados(lista)
    Util2.mostrar("Aprobaron #{aprobados} estudiantes y reprobaron #{reprobados}", :mensaje)

    agregar_estado(lista)
    |> IO.inspect(label: "Estado de los estudiantes")

    ordenar_por_nota(lista)
    |> Enum.each(fn estudiante ->
      Util2.mostrar("#{estudiante.nombre}: #{estudiante.nota}", :mensaje)
    end)

    nombres_aprobados(lista)
    |> IO.inspect(label: "Estudiantes que aprobaron")
  end

  def calcular_promedio([]), do: 0

  def calcular_promedio(lista) do
    # Es necesario extraer la nota de cada estudiante
    Enum.map(lista, & &1.nota)
    |> Enum.sum()
    # then() permite encadenar operaciones
    |> then(&(&1 / length(lista)))
  end

  def obtener_estudiantes_min_max(lista) do
    # Enum.min_by permite asociar una función para acceder a la nota
    peor = Enum.min_by(lista, & &1.nota)
    mejor = Enum.max_by(lista, & &1.nota)
    {peor, mejor}
  end

  def contar_segun_promedio(lista, promedio) do
    menores = Enum.count(lista, &(&1.nota < promedio))
    mayores = Enum.count(lista, &(&1.nota > promedio))
    {menores, mayores}
  end

  def contar_aprobados_reprobados(lista) do
    total = length(lista)
    aprobados = Enum.count(lista, &(&1.nota >= 3))
    {aprobados, total - aprobados}
  end

  def agregar_estado(lista) do
    Enum.map(lista, fn estudiante ->
      estado =
        cond do
          estudiante.nota >= 3 -> :aprobado
          # Cuando no se cumple la condición anterior
          true -> :reprobado
        end

      {estudiante.nombre, estado}
    end)
  end

  # def agregar_estado(lista) do
  #   Enum.map(lista, fn %{nombre: nombre, nota: nota} ->
  #     estado =
  #       cond do
  #         nota >= 3 -> :aprobado
  #         true -> :reprobado
  #       end

  #     {nombre, estado}
  #   end)
  # end

  # def agregar_estado(lista) do
  #   Enum.map(lista, &{&1.nombre, if(&1.nota >= 3, do: :aprobado, else: :reprobado)})
  # end

  def ordenar_por_nota(lista) do
    Enum.sort_by(lista, fn estudiante -> estudiante.nota end, :desc)
  end

  # def ordenar_por_nota(lista) do
  #   Enum.sort_by(lista, & &1.nota, :desc)
  # end

  # def nombres_aprobados(lista) do
  #   lista
  #   |> Enum.filter(&(&1.nota >= 3))
  #   |> Enum.map(& &1.nombre)
  # end

  defp nombres_aprobados(lista) do
    for %{nombre: nombre, nota: nota} <- lista, nota >= 3, do: nombre
  end
end

Estudiantes.main()
