defmodule Colecciones do
  def main do
    [
      Reserva.crear("Ana", 18, true),
      Reserva.crear("Juan", 21),
      Reserva.crear("Cesar", 48, true),
      Reserva.crear("Anibal", 65)
    ]
    |> Util2.ordenar(:asc, &{&1.nombre, &1.necesidad_especial})
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
