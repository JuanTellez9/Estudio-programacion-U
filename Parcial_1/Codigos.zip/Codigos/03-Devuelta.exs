defmodule EntradaEnteros do
  def main do
    valor_total =
      "Ingresar valor total de la factura: "
      |> Util2.ingresar(:entero)

    valor_entregado =
      "Ingresar valor entregado: "
      |> Util2.ingresar(:entero)

    calcular_devuelta(valor_entregado, valor_total)
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  def calcular_devuelta(valor_entregado, valor_total) do
    valor_entregado - valor_total
  end

  def generar_mensaje(devuelta) do
    "El valor de devuelta es $#{devuelta}"
  end
end

EntradaEnteros.main()
