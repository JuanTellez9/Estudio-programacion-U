#!/usr/bin/env bash

rm Elixir.Util2.beam
elixirc Util2.ex