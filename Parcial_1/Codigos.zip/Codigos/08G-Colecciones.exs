defmodule Colecciones do
  defmodule Reserva do
    defstruct nombre: "", edad: 0, necesidad_especial: false

    def crear(
          nombre,
          edad,
          necesidad_especial \\ false
        ) do
      %Reserva{
        nombre: nombre,
        edad: edad,
        necesidad_especial: necesidad_especial
      }
    end

    def convertir_cadena(%Reserva{
          nombre: nombre,
          edad: edad,
          necesidad_especial: true
        }) do
      "- #{nombre}, #{edad} años, con necesidad especial.\n"
    end

    def convertir_cadena(%Reserva{
          nombre: nombre,
          edad: edad
        }) do
      "- #{nombre}, #{edad} años.\n"
    end
  end

  def main do
    [
      Reserva.crear("Ana", 18, true),
      Reserva.crear("Juan", 21),
      Reserva.crear("Cesar", 48, true),
      Reserva.crear("Anibal", 65)
    ]
    |> Util2.ordenar(:asc, &{&1.nombre, &1.necesidad_especial})
    |> Util2.convertir_coleccion_mensaje(&Reserva.convertir_cadena/1)
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
