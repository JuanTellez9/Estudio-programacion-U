defmodule Colecciones do
  def main do
    ["Diana", "Julian", "Ana", "Juan", "Carmen", "Nolberto", "Cesar", "July"]
    |> Util2.aplicar_filtro_longitud(4)
    |> Util2.aplicar_filtro_inicial("Ju")
    |> Util2.ordenar(:desc)
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
