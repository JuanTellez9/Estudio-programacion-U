defmodule Mensaje do
  def main do
    crear_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  defp crear_mensaje() do
    "Bienvenidos a la empresa Once Ltda"
  end
end

Mensaje.main()
