#!/usr/bin/env bash

echo "{application, util2, [{modules, ['Elixir.Util2']}]}." > util2.app

~/.mix/escripts/ex_doc "Util2" "2.0.0" . -m "Util2" -o doc

if [ $? -ne 0 ]; then
    echo
    echo "Error generando la documentación."
    exit 1
fi

cd doc || exit 1

# Linux

xdg-open index.html
