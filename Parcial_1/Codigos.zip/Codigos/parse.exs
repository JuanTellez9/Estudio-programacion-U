defmodule ParseEntero do
  def main do
    "Ingrese un valor: "
    |> Util2.ingresar(:texto)
    |> Integer.parse()
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  def generar_mensaje(:error) do
    "Hay errores en los datos"
  end

  def generar_mensaje({valor, ""}) do
    "El valor ingresado es #{valor}"
  end

  def generar_mensaje({valor, complemento}) do
    "El valor ingresado es #{valor} y sobra #{complemento}"
  end
end

ParseEntero.main()
