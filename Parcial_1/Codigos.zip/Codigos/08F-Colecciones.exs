defmodule Colecciones do
  def main do
    Util2.ingresar("\nIngrese un nombre: ", :coleccion_textos)
    |> Util2.ordenar()
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
