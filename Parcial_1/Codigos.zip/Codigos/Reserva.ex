defmodule Reserva do
  defstruct nombre: "", edad: 0, necesidad_especial: false

  def crear(
        nombre,
        edad,
        necesidad_especial \\ false
      ) do
    %Reserva{
      nombre: nombre,
      edad: edad,
      necesidad_especial: necesidad_especial
    }
  end

  def ingresar do
    Util2.mostrar("\nIngrese los datos de la reserva\n", :mensaje)

    crear(
      Util2.ingresar("\tNombre: ", :texto),
      Util2.ingresar("\tEdad  : ", :entero),
      Util2.ingresar("\tNecesidad especial (s/n): ", :boolean)
    )
  end

  defimpl String.Chars, for: Reserva do
    def to_string(%Reserva{
          nombre: nombre,
          edad: edad,
          necesidad_especial: true
        }) do
      "#{nombre}, #{edad} años, con necesidad especial."
    end

    def to_string(%Reserva{
          nombre: nombre,
          edad: edad
        }) do
      "#{nombre}, #{edad} años."
    end
  end
end
