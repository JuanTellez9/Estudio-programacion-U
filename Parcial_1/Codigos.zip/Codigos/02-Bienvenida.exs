defmodule EntradaDatos do
  def main do
    "Ingrese nombre del empleado: "
    |> Util2.ingresar(:texto)
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  def generar_mensaje(nombre) do
    "Bienvenido #{nombre} a la empresa Once Ltda"
  end
end

EntradaDatos.main()
