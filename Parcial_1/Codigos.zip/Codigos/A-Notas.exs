defmodule Estudiantes do
  def main do
    # Se define una lista con las notas de los estudiantes (para probar las funciones)
    lista = [3, 4, 4.6, 1.6, 2.3, 4.5, 1]

    promedio = calcular_promedio(lista)
    Util2.mostrar("El promedio es #{promedio}", :mensaje)

    {menores, mayores} = contar_segun_promedio(lista, promedio)
    Util2.mostrar("Hay #{menores} por debajo del promedio y #{mayores} por encima", :mensaje)

    {menor, mayor} = obtener_estudiantes_min_max(lista)
    Util2.mostrar("La nota más baja es #{menor} y la más alta #{mayor}", :mensaje)

    {aprobados, reprobados} = contar_aprobados_reprobados(lista)
    Util2.mostrar("Aprobaron #{aprobados} estudiantes y reprobaron #{reprobados}", :mensaje)
  end

  def calcular_promedio([]), do: 0
  def calcular_promedio(lista), do: Enum.sum(lista) / length(lista)

  defp obtener_estudiantes_min_max(lista), do: Enum.min_max(lista)

  defp contar_segun_promedio(lista, promedio) do
    # Se usa una función lambda que compara cada elemento con el promedio en ambas llamadas a Enum.count
    menores = Enum.count(lista, &(&1 < promedio))
    mayores = Enum.count(lista, &(&1 > promedio))
    {menores, mayores}
  end

  defp contar_aprobados_reprobados(lista) do
    total = length(lista)
    # Se usa una función lambda que verifica si cada nota es mayor o igual a 3
    aprobados = Enum.count(lista, &(&1 >= 3))
    reprobados = total - aprobados
    {aprobados, reprobados}
  end
end

Estudiantes.main()
