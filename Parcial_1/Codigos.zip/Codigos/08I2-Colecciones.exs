defmodule Coleccion do
  def main do
    # Util2.ingresar(&Reserva.ingresar/0, :coleccion)
    [
      Reserva.crear("Ana", 18, true),
      Reserva.crear("Juan", 2),
      Reserva.crear("Cesar", 48, true),
      Reserva.crear("Anibal", 4)
    ]
    |> Util2.aplicar_filtro(&(&1.edad < 18))
    |> Util2.ordenar(:asc, & &1.nombre)
    |> Util2.convertir_coleccion_mensaje()
    |> Util2.mostrar(:mensaje)
  end
end

Coleccion.main()
