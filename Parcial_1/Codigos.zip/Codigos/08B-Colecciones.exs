defmodule Colecciones do
  def main do
    ["Diana", "Julian", "Juan", "Ana"]
    |> Util2.convertir_coleccion_mensaje(fn elemento -> "#{elemento}\t" end)
    |> Util2.mostrar(:mensaje)
  end
end

Colecciones.main()
