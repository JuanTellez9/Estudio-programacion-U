defmodule Demo do
  def main do
    "Diana"
    |> generar_saludo()
    |> Util2.mostrar(:mensaje)
  end

  def generar_saludo(nombre \\ "Ana"), do: "Hola #{nombre}"
end

Demo.main()
