# Util2 v2.0.0 - API Reference

## Modules

- [Reserva](Reserva.md)
- [Util2](Util2.md): Funciones auxiliares de propósito general para entrada y salida de datos,
procesamiento de colecciones y conversión de sus elementos a texto.

