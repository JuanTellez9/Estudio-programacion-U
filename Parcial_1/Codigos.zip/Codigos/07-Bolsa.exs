defmodule DatosLogicos do
  def main do
    "Ingrese el tipo de bolsa: "
    |> Util2.ingresar(:texto)
    |> obtener_porcentaje_descuento()
    |> generar_mensaje()
    |> Util2.mostrar(:mensaje)
  end

  # defp obtener_porcentaje_descuento(tipo_bolsa) do
  #   if tipo_bolsa == "plastica" do
  #     2.0
  #   else
  #     if tipo_bolsa == "biodegradable" do
  #       12.0
  #     else
  #       if tipo_bolsa == "reutilizable" do
  #         17.0
  #       else
  #         0.0
  #       end
  #     end
  #   end
  # end

  # defp obtener_porcentaje_descuento(tipo_bolsa) do
  #   cond do
  #     tipo_bolsa == "plastica" -> 2.0
  #     tipo_bolsa == "biodegradable" -> 12.0
  #     tipo_bolsa == "reutilizable" -> 17.0
  #     true -> 0.0
  #   end
  # end

  # defp obtener_porcentaje_descuento(tipo_bolsa) do
  #   case tipo_bolsa do
  #     "plastica" -> 2.0
  #     "biodegradable" -> 12.0
  #     "reutilizable" -> 17.0
  #     _ -> 0.0
  #   end
  # end

  # defp obtener_porcentaje_descuento(tipo_bolsa)
  #      when tipo_bolsa == "plastica", do: 2.0

  # defp obtener_porcentaje_descuento(tipo_bolsa)
  #      when tipo_bolsa == "biodegradable", do: 12.0

  # defp obtener_porcentaje_descuento(tipo_bolsa)
  #      when tipo_bolsa == "reutilizable", do: 17.0

  # defp obtener_porcentaje_descuento(_), do: 0.0

  defp obtener_porcentaje_descuento("plastica"), do: 2.0
  defp obtener_porcentaje_descuento("biodegradable"), do: 12.0
  defp obtener_porcentaje_descuento("reutilizable"), do: 17.0
  defp obtener_porcentaje_descuento(_), do: 0.0

  def generar_mensaje(porcentaje) do
    "El porcentaje es de #{porcentaje}%"
  end
end

DatosLogicos.main()
